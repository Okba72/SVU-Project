module.exports = {
    mongoURI: 'mongodb+srv://ok123:ok123@tmcluster-toabq.mongodb.net/test?retryWrites=true&w=majority'
};